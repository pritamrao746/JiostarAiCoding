# Production-Grade Architecture Restructuring for Stream Telemetry Processing

Restructure the existing prototype into a production-grade, layered Java architecture separating **DTOs**, **Domain POJOs**, **Activity Layer (Ingestion & Validation)**, **Component Layer (Stateful Aggregation & Enrichment)**, and **DAO Layer (Validation & Persistence)**.

## Architecture Overview

```
[Kafka Topic]
     │
     ▼
[Activity Layer: HeartbeatIngestionActivity]
     │  - Ingests raw DTOs
     │  - Schema & semantic validation (timestamp ranges, null checks, positive numbers)
     │  - Transforms DTO -> Internal Domain Event
     ▼
[Component Layer: HeartbeatAggregatorComponent]
     │  - Stream-side metadata enrichment (contentId -> contentType)
     │  - High-throughput dimensional accumulation by AggregationKey
     │  - Dual flush policy (time-based & batch-size thresholds)
     │  - Transforms in-memory state -> Downstream Entity POJO
     ▼
[DAO Layer: HeartbeatMetricsDao]
     │  - Validates batch payload & integrity constraints
     │  - Persists to ClickHouse (List sink / database client)
     │  - Provides query interfaces for time-range lookups
     ▼
[ClickHouse Storage / Downstream Sink]
```

## User Review Required

> [!NOTE]
> We will organize code under a clean package structure `com.streaming.heartbeat` with dedicated packages for each architectural tier.

## Proposed Changes

### 1. Data Transfer Objects (DTO) & Domain POJOs
- [NEW] `com/streaming/heartbeat/dto/HeartbeatKafkaMessageDto.java`: Raw message payload received from Kafka broker.
- [NEW] `com/streaming/heartbeat/model/HeartbeatEvent.java`: Sanitized and validated domain event.
- [NEW] `com/streaming/heartbeat/model/AggregationKey.java`: Compound record for grouping `(windowStartEpochMs, platform, failureErrorCode, region, contentType)`.
- [NEW] `com/streaming/heartbeat/model/HeartbeatMetricRecord.java`: Output POJO entity consumed by the DAO layer.

### 2. Activity Layer (Validation & Routing)
- [NEW] `com/streaming/heartbeat/activity/HeartbeatIngestionActivity.java`: Interface for Kafka consumer ingestion.
- [NEW] `com/streaming/heartbeat/activity/HeartbeatIngestionActivityImpl.java`: Validates raw DTOs (null/empty checks, timestamp bounds, non-negative numbers) and forwards valid events to the component layer.
- [NEW] `com/streaming/heartbeat/exception/ValidationException.java`: Custom exception for validation errors.

### 3. Component Layer (Enrichment & Stateful Rollup)
- [NEW] `com/streaming/heartbeat/component/HeartbeatAggregatorComponent.java`: Aggregator interface.
- [NEW] `com/streaming/heartbeat/component/HeartbeatAggregatorComponentImpl.java`:
  - Coordinates metadata enrichment via `MetadataEnricher`.
  - Performs window alignment (e.g. 60-second tumbling windows).
  - Uses `ReentrantReadWriteLock` for low-contention atomic buffer swapping.
  - Converts accumulated state into `HeartbeatMetricRecord` POJOs.
  - Passes aggregated batches to `HeartbeatMetricsDao`.
- [NEW] `com/streaming/heartbeat/component/enricher/MetadataEnricher.java`: Interface for metadata lookup.
- [NEW] `com/streaming/heartbeat/component/enricher/DefaultMetadataEnricher.java`: Local cache-backed enricher (`contentId` -> `contentType`).
- [NEW] `com/streaming/heartbeat/component/accumulator/MetricAccumulator.java`: Accumulates sums, counts, and distinct user sets.

### 4. DAO Layer (Persistence & Querying)
- [NEW] `com/streaming/heartbeat/dao/HeartbeatMetricsDao.java`: DAO interface for batch persistence and analytical queries.
- [NEW] `com/streaming/heartbeat/dao/ClickHouseHeartbeatMetricsDao.java`:
  - Validates incoming batches (non-null, valid window timestamps, valid counts).
  - Persists batches into downstream ClickHouse storage (synchronized list).
  - Implements analytical time-range query methods (Query 1: download bytes for platform; Query 2: unique users for error code).
- [NEW] `com/streaming/heartbeat/exception/DaoException.java`: Custom exception for persistence errors.

### 5. Integration Test / Demonstration
- [NEW] `com/streaming/heartbeat/HeartbeatPipelineIntegrationTest.java`:
  - Wires up Activity -> Component -> DAO.
  - Tests validation rejection for malformed DTOs.
  - Tests concurrent ingestion and periodic/batch flushing.
  - Verifies Query 1 (bytes by platform) and Query 2 (unique users with error) against the DAO.

## Verification Plan

### Automated Tests
- Run `javac` across all packages:
  `javac -d out $(find src -name "*.java")`
- Run integration test:
  `java -cp out com.streaming.heartbeat.HeartbeatPipelineIntegrationTest`

### Manual Verification
- Verify that malformed messages are caught and handled by the Activity layer without affecting subsequent events.
- Verify that accumulated records in the DAO contain enriched `contentType` and correct aggregated metric values.
- Verify accurate answers to Query 1 and Query 2 over multi-minute windows.
