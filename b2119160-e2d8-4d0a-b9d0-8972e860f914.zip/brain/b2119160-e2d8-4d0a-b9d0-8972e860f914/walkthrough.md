# Stream Heartbeat Processing Architecture Walkthrough

We restructured the stream telemetry processor into a clean, decoupled, enterprise-ready multi-tier architecture in Java.

## Package & File Structure

```
src/com/streaming/heartbeat/
├── dto/
│   └── HeartbeatKafkaMessageDto.java           # Raw Kafka payload DTO
├── model/
│   ├── HeartbeatEvent.java                     # Validated internal domain model
│   ├── AggregationKey.java                     # 5-tuple dimensional slice key
│   └── HeartbeatMetricRecord.java              # Output entity POJO for DAO persistence
├── exception/
│   ├── ValidationException.java                # Activity-layer validation errors
│   └── DaoException.java                       # DAO-layer persistence errors
├── activity/
│   ├── HeartbeatIngestionActivity.java         # Activity interface
│   └── HeartbeatIngestionActivityImpl.java     # Ingestion validation & mapping
├── component/
│   ├── HeartbeatAggregatorComponent.java       # Component interface
│   ├── HeartbeatAggregatorComponentImpl.java   # Stateful aggregation & atomic buffer flush
│   ├── enricher/
│   │   ├── MetadataEnricher.java               # Enrichment interface
│   │   └── DefaultMetadataEnricher.java        # Cache-backed content resolver
│   └── accumulator/
│       └── MetricAccumulator.java              # In-memory metrics & distinct user sets
├── dao/
│   ├── HeartbeatMetricsDao.java                # DAO interface & query methods
│   └── ClickHouseHeartbeatMetricsDao.java      # Data validation & ClickHouse persistence
└── HeartbeatPipelineIntegrationTest.java       # End-to-end integration test runner
```

---

## Architectural Flow & Layer Responsibilities

```mermaid
flowchart TD
    Kafka["Kafka Consumer"] -->|HeartbeatKafkaMessageDto| Activity["Activity Layer<br/>(HeartbeatIngestionActivity)"]
    Activity -->|Schema & Range Validation| ActivityCheck{"Valid?"}
    ActivityCheck -- No --> Reject["Throw ValidationException<br/>(or DLQ)"]
    ActivityCheck -- Yes -->|HeartbeatEvent| Component["Component Layer<br/>(HeartbeatAggregatorComponent)"]
    
    subgraph Component Layer
        Enricher["MetadataEnricher<br/>(contentId -> contentType)"] -.-> Component
        Component --> InMem["In-Memory Accumulator<br/>(ReadWriteLock Buffer)"]
        InMem --> FlushCheck{"Flush Trigger?<br/>(Interval or Max Keys)"}
        FlushCheck -->|Atomic Buffer Swap| Transform["Transform to POJOs<br/>List&lt;HeartbeatMetricRecord&gt;"]
    end
    
    Transform -->|Batch of POJOs| DAO["DAO Layer<br/>(HeartbeatMetricsDao)"]
    
    subgraph DAO Layer
        DAO --> DAOValidation["Batch & Integrity Validation"]
        DAOValidation --> ClickHouse["ClickHouse Persistence<br/>(List Sink / Table)"]
        ClickHouse --> QueryEngine["Analytical Queries<br/>- Bytes by Platform<br/>- Unique Users with Error"]
    end
```

### 1. Activity Layer (`HeartbeatIngestionActivity`)
* **Role**: First line of defense for Kafka events.
* **Validations performed**:
  - Null/blank checks on `userId` and `contentId`.
  - Timestamp boundary validation (normalizes epoch seconds vs milliseconds).
  - Bounds checks (`downloadBytes >= 0`, `durationPlayed >= 0`, `rebufferDuration >= 0`).
  - Normalization of `platform`, `region`, and error codes (`null` $\to$ `"NO_ERROR"`).
* **Output**: Maps validated DTO into an immutable `HeartbeatEvent` domain object and forwards it to the component layer.

### 2. Component Layer (`HeartbeatAggregatorComponent`)
* **Role**: State management, metadata enrichment, and batch creation.
* **Enrichment**: Queries `MetadataEnricher` to resolve `contentType` (`LIVE`, `MOVIE`, `SERIES`, `VOD`) from `contentId`.
* **State Rollup**: Buckets timestamps into 60-second tumbling windows and aggregates by:
  $$\text{AggregationKey} = (\text{windowStart}, \text{platform}, \text{errorCode}, \text{region}, \text{contentType})$$
* **High-Throughput Concurrency**:
  - Uses `ReentrantReadWriteLock` so that ingestion threads run in parallel under a shared read lock.
  - Periodic flushes and size thresholds swap the buffer pointer under a microsecond write lock, pushing transformed `HeartbeatMetricRecord` POJOs to the DAO outside the lock.

### 3. DAO Layer (`HeartbeatMetricsDao`)
* **Role**: Data persistence and analytical querying.
* **Validations**: Enforces DAO-level constraints (non-null batch, non-negative totals, positive event counts).
* **Storage**: Appends validated batches to the downstream ClickHouse sink (`List<HeartbeatMetricRecord>`).
* **Analytical Query Capabilities**:
  - `queryTotalDownloadBytes(start, end, platform)`: Filters by window and platform, summing download bytes.
  - `queryUniqueUsersWithErrorCode(start, end, errorCode)`: Filters by window and error code, performing a set union of unique users across time windows to eliminate duplicate counts.

---

## Verification & Test Results

The pipeline was verified with `com.streaming.heartbeat.HeartbeatPipelineIntegrationTest`:

```bash
javac -d out $(find src -name "*.java")
java -cp out com.streaming.heartbeat.HeartbeatPipelineIntegrationTest
```

### Execution Log:
```text
===================================================================
 RUNNING PRODUCTION PIPELINE INTEGRATION TESTS
 Architecture: Activity (Validation) -> Component (Rollup) -> DAO
===================================================================

--- Test 1: Testing Activity Validation Rules ---
  ✓ Correctly rejected: Null DTO -> Kafka message payload is null.
  ✓ Correctly rejected: Blank userId -> Validation failed: 'userId' cannot be null or empty.
  ✓ Correctly rejected: Blank contentId -> Validation failed: 'contentId' cannot be null or empty.
  ✓ Correctly rejected: Negative downloadBytes -> Validation failed: 'downloadBytes' cannot be negative (-50).
  ✓ Correctly rejected: Negative timestamp -> Validation failed: 'timestamp' must be a positive epoch number.
✓ All validation rejections verified!

--- Test 2: End-to-End Ingestion, Enrichment & Target Queries ---
Flushed 4 aggregated records into ClickHouse DAO.

Persisted Records in DAO:
  [2026-09-21T14:13:00Z] Platform: Android | Error: XYZ      | ContentType: MOVIE  | Events: 3 | Bytes: 4,500,000 | Users: 2
  [2026-09-21T14:14:00Z] Platform: Android | Error: XYZ      | ContentType: MOVIE  | Events: 2 | Bytes: 4,000,000 | Users: 2
  [2026-09-21T14:13:00Z] Platform: Android | Error: NO_ERROR | ContentType: LIVE   | Events: 1 | Bytes: 5,000,000 | Users: 1
  [2026-09-21T14:13:00Z] Platform: iOS     | Error: XYZ      | ContentType: MOVIE  | Events: 1 | Bytes: 3,000,000 | Users: 1

-----------------------------------------------------------------
QUERY 1 Result (Android Total Bytes): 13,500,000 bytes
✓ Query 1 Verified!
QUERY 2 Result (Unique Users Facing 'XYZ'): 4 unique users
✓ Query 2 Verified!
-----------------------------------------------------------------

--- Test 3: Concurrent Ingestion & Background Auto-Flush ---
Total Ingested Events: 1,600 (Expected: 1,600)
Total Download Bytes: 800,000 (Expected: 800,000)
Total Aggregated Rolled-up Rows: 12
✓ Concurrent Ingestion Stress Test Passed without lost updates!

ALL INTEGRATION TESTS COMPLETED SUCCESSFULLY!
```
